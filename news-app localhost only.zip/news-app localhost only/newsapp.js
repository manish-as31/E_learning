const API_KEY = "60947cac199341f9a8e2bf4fa7bc6d50";
const url = "https://newsapi.org/v2/everything?q=";

window.addEventListener("load", () => fetchNews("Technology"));

async function fetchNews(query) {
    try {
        const loadingSpinner = document.getElementById('loading-spinner');
        loadingSpinner.style.display = 'block';
        const res = await fetch(`${url}${query}&apiKey=${API_KEY}`);
        const data = await res.json();
        if (data.status === "ok") {
            currentArticles = data.articles;
            displayNews(currentArticles);
        } else {
            throw new Error(data.message || 'Failed to fetch news');
        }
    } catch (error) {
        console.error('Error:', error);
        const newsCardContainer = document.getElementById("cardscontainer");
        newsCardContainer.innerHTML = '<h2>An error occurred while fetching the news</h2>';
    } finally {
        loadingSpinner.style.display = 'none';
    }
}

let currentArticles = [];

function displayNews(articles) {
    const newsCardContainer = document.getElementById("cardscontainer");
    newsCardContainer.innerHTML = "";

    if (!articles || articles.length === 0) {
        newsCardContainer.innerHTML = '<h2>No articles found</h2>';
        return;
    }

    articles.forEach((article) => {
        if (!article.urlToImage) return;
        const cardClone = createNewsCard(article);
        newsCardContainer.appendChild(cardClone);
    });
}

function createNewsCard(article) {
    const div = document.createElement('div');
    div.className = 'card';
    
    const bookmarkIcon = document.createElement('span');
    bookmarkIcon.className = 'bookmark-icon';
    bookmarkIcon.textContent = bookmarks.some(b => b.url === article.url) ? '★' : '☆';
    bookmarkIcon.addEventListener('click', (e) => {
        e.stopPropagation();
        const isNowBookmarked = toggleBookmark(article);
        bookmarkIcon.textContent = isNowBookmarked ? '★' : '☆';
    });

    div.innerHTML = `
        <div class="card-header">
            <img src="${article.urlToImage || 'https://via.placeholder.com/400x200'}" alt="news-image" id="news-img">
        </div>
        <div class="card-content">
            <h3 id="news-title">${article.title}</h3>
            <h6 class="news-source" id="news-source">${article.source.name} • ${new Date(article.publishedAt).toLocaleDateString()}</h6>
            <p class="news-desc" id="news-desc">${article.description || ''}</p>
        </div>
    `;
    
    div.insertBefore(bookmarkIcon, div.firstChild);
    
    div.addEventListener('click', () => {
        window.open(article.url, '_blank');
    });
    
    return div;
}

// Dark mode toggle
const themeToggle = document.getElementById('theme-toggle');
themeToggle.addEventListener('click', () => {
    const isDark = document.body.getAttribute('data-theme') === 'dark';
    document.body.setAttribute('data-theme', isDark ? 'light' : 'dark');
    themeToggle.textContent = isDark ? '🌙' : '☀️';
    localStorage.setItem('theme', isDark ? 'light' : 'dark');
});

// Load saved theme
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
    document.body.setAttribute('data-theme', savedTheme);
    themeToggle.textContent = savedTheme === 'dark' ? '☀️' : '🌙';
}

// Bookmarks functionality
let bookmarks = JSON.parse(localStorage.getItem('bookmarks') || '[]');
const bookmarksModal = document.getElementById('bookmarks-modal');
const closeModal = document.querySelector('.close-modal');
const showBookmarksBtn = document.getElementById('show-bookmarks');

showBookmarksBtn.addEventListener('click', () => {
    displayBookmarks();
    bookmarksModal.style.display = 'block';
});

closeModal.addEventListener('click', () => {
    bookmarksModal.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === bookmarksModal) {
        bookmarksModal.style.display = 'none';
    }
});

function displayBookmarks() {
    const container = document.getElementById('bookmarks-container');
    container.innerHTML = '';
    
    if (bookmarks.length === 0) {
        container.innerHTML = '<p>No bookmarks yet!</p>';
        return;
    }

    bookmarks.forEach(article => {
        const articleElement = createNewsCard(article);
        container.appendChild(articleElement);
    });
}

function toggleBookmark(article) {
    const index = bookmarks.findIndex(b => b.url === article.url);
    if (index === -1) {
        bookmarks.push(article);
    } else {
        bookmarks.splice(index, 1);
    }
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    return index === -1;
}

// Navigation
let curSelectedNav = null;
function onNavItemClick(id) {
    fetchNews(id);
    const navItem = document.getElementById(id);
    curSelectedNav?.classList.remove('active');
    curSelectedNav = navItem;
    curSelectedNav.classList.add('active');
}

// Search functionality
const searchButton = document.getElementById("search-button");
const searchText = document.getElementById("search-text");

searchButton.addEventListener("click", () => {
    const query = searchText.value;
    if (!query) return;
    fetchNews(query);
    curSelectedNav?.classList.remove('active');
    curSelectedNav = null;
});

searchText.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        const query = searchText.value;
        if (!query) return;
        fetchNews(query);
        curSelectedNav?.classList.remove('active');
        curSelectedNav = null;
    }
});

// reponsive design 

document.querySelector('.hamburger').addEventListener('click', function() {
    document.querySelector('.nav-links').classList.toggle('active');
});

function handleLogout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userEmail');
    window.location.href = 'landing.html';
}
